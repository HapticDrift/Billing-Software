
package demo.billingsoftware;

public class Main 
{
    public static void main(String[] args) {
        new StarttPanel().setVisible(true);
        
    }
    
}
